from django.contrib import admin
from .models import Fish, Order, Delivery

admin.site.register(Fish)
admin.site.register(Order)
admin.site.register(Delivery)

# core/urls.py

from django.urls import path
from django.conf import settings
from django.conf.urls.static import static


from . import views

app_name = "core"

urlpatterns = [
    path("", views.landing_page_view, name="landing_page"),
    path("detail/<int:pk>", views.fish_detail, name="fish_detail"),
    path("order/<int:pk>", views.place_order, name="order"),
    path(
        "order/confirm/<int:order_id>",
        views.order_confirmation,
        name="order_confirmation",
    ),
    path("orders/", views.order_list, name="order_list"),

    path('deliveries/create/<int:order_id>/', views.create_delivery, name='create_delivery'),
    path('deliveries/update-status/', views.update_delivery_status, name='update_delivery_status'),
    path('fish/<int:pk>/pdf/', views.generate_fish_pdf, name='generate_fish_pdf'),

]

urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)
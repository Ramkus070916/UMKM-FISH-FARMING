import decimal
from django.shortcuts import render
from .models import Fish
from django.shortcuts import render, redirect, get_object_or_404

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Fish, Order
from django.urls import reverse
from .models import Delivery, Order
from django.utils import timezone
from django.http import JsonResponse



from django.shortcuts import render
from .models import Fish

def landing_page_view(request):
    query = request.GET.get("query", "")
    price_filter = request.GET.get("price_filter", "")
    fish_list = Fish.objects.all()

    if request.user.is_authenticated:
        return redirect("core:order_list")

    if query:
        fish_list = fish_list.filter(name__icontains=query)

    if price_filter:
        if price_filter == "low_to_high":
            fish_list = fish_list.order_by("price_per_kg")
        elif price_filter == "high_to_low":
            fish_list = fish_list.order_by("-price_per_kg")

    return render(
        request,
        "landing_page.html",
        {"fish_list": fish_list, "query": query, "price_filter": price_filter},
    )



def fish_detail(request, pk):
    fish = get_object_or_404(Fish, id=pk)
    return render(request, "fish_detail.html", {"fish": fish})


def place_order(request, pk):
    fish = get_object_or_404(Fish, id=pk)
    if request.method == "POST":
        customer_name = request.POST["customer_name"]
        customer_email = request.POST["customer_email"]
        customer_phone = request.POST["customer_phone"]
        address = request.POST["address"]
        quantity_kg = request.POST["quantity_kg"]

        try:
            quantity_kg = float(quantity_kg)
            if quantity_kg > fish.stock_kg:
                messages.error(request, "Not enough stock available.")
            else:
                order = Order(
                    customer_name=customer_name,
                    customer_email=customer_email,
                    customer_phone=customer_phone,
                    address=address,
                    fish=fish,
                    quantity_kg=quantity_kg,
                    is_paid=False,
                )
                fish.stock_kg -= decimal.Decimal(quantity_kg)
                fish.save()
                order.save()
                messages.success(request, "Order placed successfully.")
                return redirect("core:order_confirmation", order_id=order.id)
        except ValueError:
            messages.error(request, "Invalid quantity value.")

    return render(request, "place_order.html", {"fish": fish})


def order_confirmation(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    return render(request, "order_confirmation.html", {"order": order})


def order_list(request):
    orders = Order.objects.filter(delivery__isnull=True)
    deliveries = Delivery.objects.all()
    return render(request, "order_list.html", {"orders": orders, "deliveries": deliveries})


def create_delivery(request, order_id):
    order = get_object_or_404(Order, pk=order_id)
    if request.method == "POST":
        delivery_date = request.POST.get("delivery_date")
        delivery_status = request.POST.get("delivery_status")

        # Validate inputs
        if delivery_date and delivery_status:
            delivery = Delivery(
                order=order,
                delivery_date=timezone.datetime.strptime(
                    delivery_date, "%Y-%m-%dT%H:%M"
                ),
                delivery_status=delivery_status,
            )
            delivery.save()
            return redirect(reverse("core:order_list"))
        else:
            error_message = "All fields are required."
            return render(
                request,
                "delivery_form.html",
                {"order": order, "error_message": error_message},
            )
    return render(request, "delivery_form.html", {"order": order})



def update_delivery_status(request):
    if request.method == 'POST':
        delivery_id = request.POST.get('delivery_id')
        status = request.POST.get('status')
        try:
            delivery = Delivery.objects.get(id=delivery_id)
            delivery.delivery_status = status
            delivery.save()
            return JsonResponse({'success': True, 'message': 'Status updated successfully'})
        except Delivery.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Delivery not found'})
    return JsonResponse({'success': False, 'message': 'Invalid request'})


import pdfkit
from django.http import HttpResponse
from django.template.loader import render_to_string
from django.conf import settings

def generate_fish_pdf(request, pk):
    # Get the Fish instance
    delivery = get_object_or_404(Delivery, id=pk)

    print("Delivery order:", delivery.order.pk)
    
    # Render the HTML template
    html = render_to_string('fish_pdf_template.html', {'delivery': delivery})
    
    # Configure pdfkit
    options = {
        'page-size': 'Letter',
        'encoding': 'UTF-8',
    }
    
    # Generate PDF
    pdf = pdfkit.from_string(html, False, options=options, configuration=pdfkit.configuration(wkhtmltopdf=settings.PDFKIT_CONFIG['wkhtmltopdf']))

    # Create response
    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="fish_{delivery.id}.pdf"'
    return response

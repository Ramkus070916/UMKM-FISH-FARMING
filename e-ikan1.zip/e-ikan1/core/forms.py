# forms.py

from django import forms


class OrderForm(forms.Form):
    customer_name = forms.CharField(
        max_length=100, widget=forms.TextInput(attrs={"class": "form-control"})
    )
    customer_email = forms.EmailField(
        widget=forms.EmailInput(attrs={"class": "form-control"})
    )
    customer_phone = forms.CharField(
        max_length=15, widget=forms.TextInput(attrs={"class": "form-control"})
    )
    address = forms.CharField(widget=forms.Textarea(attrs={"class": "form-control"}))
    quantity_kg = forms.DecimalField(
        max_digits=5,
        decimal_places=2,
        widget=forms.NumberInput(attrs={"class": "form-control"}),
    )
